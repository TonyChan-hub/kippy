# native_kit_flutter

Flutter facade for NativeKit.

```dart
import 'package:native_kit_flutter/native_kit_flutter.dart';

final status = await NativeKit.permission.ensure(PermissionKind.camera);
// also: microphone, photoRead, photoAdd, locationWhenInUse,
//       locationAlways, notification, contacts, calendar, tracking
```

Docs: [NativeKit guide](https://tonychan-hub.github.io/AppSetup/guide/native-kit) (integration + API).
