import 'permission.dart';

class NativeKit {
  NativeKit._();

  static const permission = NativeKitPermission();
}
