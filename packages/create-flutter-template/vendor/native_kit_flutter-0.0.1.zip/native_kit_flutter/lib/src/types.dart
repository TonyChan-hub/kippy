enum PermissionKind {
  camera,
  microphone,
  photoRead,
  photoLimited,
  photoAdd,
  locationWhenInUse,
  locationAlways,
  notification,
  contacts,
  calendar,
  tracking,
}

enum PermissionStatus {
  granted,
  denied,
  permanentlyDenied,
  restricted,
  limited,
  notDetermined,
}

extension PermissionKindWire on PermissionKind {
  String get wireName {
    switch (this) {
      case PermissionKind.camera:
        return 'camera';
      case PermissionKind.microphone:
        return 'microphone';
      case PermissionKind.photoRead:
        return 'photoRead';
      case PermissionKind.photoLimited:
        return 'photoLimited';
      case PermissionKind.photoAdd:
        return 'photoAdd';
      case PermissionKind.locationWhenInUse:
        return 'locationWhenInUse';
      case PermissionKind.locationAlways:
        return 'locationAlways';
      case PermissionKind.notification:
        return 'notification';
      case PermissionKind.contacts:
        return 'contacts';
      case PermissionKind.calendar:
        return 'calendar';
      case PermissionKind.tracking:
        return 'tracking';
    }
  }
}

PermissionStatus permissionStatusFromWire(String value) {
  switch (value) {
    case 'granted':
      return PermissionStatus.granted;
    case 'denied':
      return PermissionStatus.denied;
    case 'permanentlyDenied':
      return PermissionStatus.permanentlyDenied;
    case 'restricted':
      return PermissionStatus.restricted;
    case 'limited':
      return PermissionStatus.limited;
    case 'notDetermined':
      return PermissionStatus.notDetermined;
    default:
      return PermissionStatus.denied;
  }
}
